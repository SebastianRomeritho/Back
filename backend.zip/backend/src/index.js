//! Require
require('dotenv').config()
const express = require('express');
//const morgan = require('morgan');



//! Require Middleware
const app = express()
var cors = require('cors');

//! Middleware
app
  //.use(morgan("dev"))
  .use(express.json())
  .use(express.urlencoded({ extended : true }))
  .use(cors())
  .use(function(req, res, next){
    res.header('Content-Type', 'application/x-www-form-urlencoded');
    next();
  })


//! Require Routes
//



//! Config
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`\n\n\n🚀 Server listening on 🌜 http://localhost:${PORT} 🌛\n`);
});







//! Routes
app.use("/api", require("./routes/v1"))