const conn = require("../config/mysql");
const mysql = require("mysql2");

const getServices = async (req, res) => {
  try {
    conn.query(
      {// sql query
        sql: `
        SELECT 
            productos.id_producto,
            productos.nombre_producto,
            productos.precio,
            productos.id_categoria,
            categoria.nombre_categoria
        FROM productos
        INNER JOIN categoria ON categoria.id_categoria = productos.id_categoria`,
        timeout: 5000,
      },
      function (err, result) {
        if (err) throw err;

        console.log("\nData obtained!");
        res.json(result);
      }
    );

    return;
  } catch (error) {
    res.status(500);
    res.send(error.message);
  }

  conn.release();
};

const newService = async (req, res, callback) => {
  try {
    const { nombre_producto, precio, id_categoria } = req.body;
    const dataService = { nombre_producto, precio, id_categoria };

    console.log(dataService);

    conn.query(
      { sql: "INSERT INTO productos SET ?", timeout: 5000 },
      dataService,
      function (err, result) {
        if (err) throw err;

        console.log("\nData send!");
        res.json(result);
      }
    );

    return;
  } catch (error) {
    res.status(500);
    res.send(error.message);
  }

  conn.release();
};

module.exports = { getServices, newService };
