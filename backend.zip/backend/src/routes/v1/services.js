const express = require('express');
const router = express.Router();

const { getServices, newService } = require('../../controllers/servicesController')

router
  .get('/', getServices)
  .get('', )
  .post('/newService', newService)

module.exports = router