require("dotenv").config();


let mysql = require('mysql');

let conn = mysql.createPool({
    host: process.env.HOST || "",
    database: process.env.DATABASE || "",
    user: process.env.USER || "",
    password: process.env.PASSWORD || ""
});

const getConnection = () => {
    return connection;
}



module.exports = conn;